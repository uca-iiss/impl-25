public class ProcesadorPago {
    public void cobrar(String cliente, double total) {
        System.out.println("Cobrando a " + cliente + ": $" + total);
    }
}