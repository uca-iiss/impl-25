public class VerificadorStock {
    public boolean hayStock(Pedido pedido) {
        System.out.println("Verificando stock para: " + pedido.getProducto());
        return true; // Simulación
    }
}